#./sipp 127.0.0.1:5060 -inf users.csv  -trace_err -sf uac.xml -i 127.0.0.1 -p 5050 -r 1 -m 1000000
sipp 127.0.0.1:5060 -sf registrar-load-test.xml -i 127.0.0.1 -p 5050 -r 1 -m 1000000
