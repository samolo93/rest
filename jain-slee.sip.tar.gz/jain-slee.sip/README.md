# jain-slee.sip
JAIN SLEE SIP Resource Adaptor Repository

[![Stories in Ready](https://badge.waffle.io/RestComm/jain-slee.sip.png?label=ready&title=Ready)](http://waffle.io/RestComm/jain-slee.sip)
